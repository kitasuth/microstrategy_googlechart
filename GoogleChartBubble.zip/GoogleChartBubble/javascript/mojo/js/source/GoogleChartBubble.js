(function () { 
    if (!mstrmojo.plugins.GoogleChartBubble) {
        mstrmojo.plugins.GoogleChartBubble = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.CustomVisBase",
        "mstrmojo.models.template.DataInterface",
        "mstrmojo.vi.models.editors.CustomVisEditorModel"
    );

    mstrmojo.plugins.GoogleChartBubble.GoogleChartBubble = mstrmojo.declare(
        mstrmojo.CustomVisBase,
        null,
        {
            scriptClass: "mstrmojo.plugins.GoogleChartBubble.GoogleChartBubble",
            cssClass: "googlechartbubble",
            errorMessage: "There is either not enough data to display the visualization or an error occurred while executing the visualization.",
            errorDetails: "This visualization requires one or more attributes and one metric.",
            externalLibraries: [{url:"www.google.com/jsapi"}],
            useRichTooltip: true,
            reuseDOMNode: false,
            supportNEE: true,
            plot:function(){



                var domNode = this.domNode, width = this.width, height = this.height, dp = this.dataInterface;
                function prepareData() {
                    var data = {};
                    
                    // Set cols //attributes column header/type
                    data.cols = [];
                    data.cols[0] = {"id": "ATT_NAME_JS", "label": "Attribute", "type": "string"};
                    // Set metrics columns header/type
                    var i; 
                    for (i = 0; i < dp.getColumnHeaderCount(); i++) {
                        var metricName = dp.getColHeaders(0).getHeader(i).getName();
                        data.cols[1 + i] = {"id": metricName, "label": metricName, "type": "number"};
                    }
                    // Set rows data
                    data.rows = [];
                    // Iterate thru all rows
                    for (i = 0; i < dp.getTotalRows(); i++) {
                        data.rows[i] = {};
                        var c = [], attributesValue = "";
                        // Set attribute values to single string for row
                        var a;
                        for (a = 0; a < dp.getRowHeaders(i).size(); a++) {
                            attributesValue += dp.getRowHeaders(i).getHeader(a).getName() + " ";
                        }
                        c[0] = {"v": attributesValue};
                        // Set metrics values in row
                        var z;
                        for (z = 0; z < dp.getColumnHeaderCount(); z++) {
                            c[1 + z] = {"v": dp.getMetricValue(i, z).getRawValue()};
                        }
                        data.rows[i].c = c;
                    }
                    return data;
                }

                function renderGraph() {
                    var data = new google.visualization.DataTable(prepareData());
                    var options = {
                            title: 'Correlation between life expectancy, fertility rate ' +
                                    'and population of some world countries (2010)',
                           hAxis: {title: 'Life Expectancy'},
                           vAxis: {title: 'Fertility Rate'},
                           bubble: {textStyle: {fontSize: 11}}
                          };
                    var chart = new google.visualization.BubbleChart(domNode);
                    chart.draw(data, options);
                }

                google.load("visualization", "1", {"callback": function () {
                    renderGraph();
                }, "packages": ["corechart"]});
            }})}());
//@ sourceURL=GoogleChartBubble.js