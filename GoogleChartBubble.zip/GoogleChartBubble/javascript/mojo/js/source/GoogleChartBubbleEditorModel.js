(function () { 
    if (!mstrmojo.plugins.GoogleChartBubble) {
        mstrmojo.plugins.GoogleChartBubble = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.editors.CustomVisEditorModel",
        "mstrmojo.array"
    );

    mstrmojo.plugins.GoogleChartBubble.GoogleChartBubbleEditorModel = mstrmojo.declare(
        mstrmojo.vi.models.editors.CustomVisEditorModel,
        null,
        {
            scriptClass: "mstrmojo.plugins.GoogleChartBubble.GoogleChartBubbleEditorModel",
            cssClass: "googlechartbubbleeditormodel",
            getCustomProperty: function getCustomProperty(){











}
})}());
//@ sourceURL=GoogleChartBubbleEditorModel.js