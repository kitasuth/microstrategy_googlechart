(function () { 
    if (!mstrmojo.plugins.GoogleChartBubble) {
        mstrmojo.plugins.GoogleChartBubble = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.CustomVisDropZones",
        "mstrmojo.array"
    );

    mstrmojo.plugins.GoogleChartBubble.GoogleChartBubbleDropZones = mstrmojo.declare(
        mstrmojo.vi.models.CustomVisDropZones,
        null,
        {
            scriptClass: "mstrmojo.plugins.GoogleChartBubble.GoogleChartBubbleDropZones",
            cssClass: "googlechartbubbledropzones",
            getCustomDropZones: function getCustomDropZones(){
  return [ 
 
 ];},
            shouldAllowObjectsInDropZone: function shouldAllowObjectsInDropZone(zone, dragObjects, idx, edge, context) {
 
  
 








},
            getActionsForObjectsDropped: function getActionsForObjectsDropped(zone, droppedObjects, idx, replaceObject, extras) {
 
  
 








},
            getActionsForObjectsRemoved: function getActionsForObjectsRemoved(zone, objects) { 
  
   
 








},
            getDropZoneContextMenuItems: function getDropZoneContextMenuItems(cfg, zone, object, el) {
 
  
 








}
})}());
//@ sourceURL=GoogleChartBubbleDropZones.js